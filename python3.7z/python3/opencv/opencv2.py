import cv2
import numpy as np
from PIL import Image 	

#загрузка изображения
image = cv2.imread('e.jpg', 1)

height, width, channels = image.shape
print (height, width)


#создание изображений
gray = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
gray1 = Image.fromarray(image)
binary = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
binary1 = Image.fromarray(image)
dst = cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
dst1 = Image.fromarray(image)
# gray    = cv2.CreateImage(cv.Get?Size(image),cv.IPL_DEPTH_8U, 1 )
# binary  = cv2.CreateImage(cv.GetSize(image),cv.IPL_DEPTH_8U, 1 )
# dst1    = cv2.CreateImage(cv.GetSize(image),cv.IPL_DEPTH_8U, 1 )

#конвертируем изображение из RGB в gray
cv2.cvtColor(image,cv2.COLOR_BGR2RGB)
#преобразуем одноканальное изображение в бинарное
cv.InRangeS(gray,cv.Scalar(30),cv.Scalar(200),binary)

#создаем хранилище памяти
storage = cv.CreateMemStorage(0)
#находим контуры бинарного изображения
contours = cv.FindContours(binary,storage,
cv.CV_RETR_TREE,cv.CV_CHAIN_APPROX_SIMPLE ,(0,0))

#рисуем контуры
while contours!= None:
    cv.DrawContours(dst1,contours,cv.CV_RGB(250,0,0), cv.CV_RGB(0,0,250),2,1,8)
    contours = contours.h_next()

#создаем матрицу из изображения dst1
mat = cv.GetMat(dst1,0)


#сохраняем полученную матрицу в xml-файл
cv.Save('matrix.xml',mat)

#Создаем окна и показываем в них изображения
cv.NamedWindow('original',cv.CV_WINDOW_AUTOSIZE)
cv.NamedWindow('gray',cv.CV_WINDOW_AUTOSIZE)
cv.NamedWindow('Contours',cv.CV_WINDOW_AUTOSIZE)
cv.NamedWindow('Binary',cv.CV_WINDOW_AUTOSIZE)
cv.ShowImage('original',image)
cv.ShowImage('gray',gray)
cv.ShowImage('Contours',dst1)
cv.ShowImage('Binary',binary)
cv.WaitKey(0) #ожидание