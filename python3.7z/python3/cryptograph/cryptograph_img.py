from PIL import Image, ImageDraw 
from random import randint		
from itertools import zip_longest
# def grouper(iterable, n):
#     args = [iter(iterable)] * n
#     return zip(*args)
class crypt:
	# @staticmethod
	def split_n(self, iterable, n):
    	 args = [iter(iterable)]*n
    	 return zip(*args)
	text=input("text:")
	keys = [] 					#сюда будут помещены ключи
	words_of_number=[]
	img = Image.open('e.jpg') 	#создаём объект изображения
	draw = ImageDraw.Draw(img)	   		#объект рисования
	width = img.size[0]  		   		#ширина
	height = img.size[1]		   		#высота	
	pix = img.load()				#все пиксели тут
	f = open('keys.txt','w')			#текстовый файл для ключей
	for elem in ([ord(elem) for elem in text]):
		words_of_number.append(elem)

	
	w=split_n(5, words_of_number, 3) 
	for elem in w:
		key = (randint(1,width-10),randint(1,height-10))
		keys.append(key)		
		g, b, r = pix[key][0:3]
		draw.point(key, (elem))
		# print(elem)														
		f.write(str(key)+'\n')
	img.save("new_e.png", "PNG")
	f.close()		

s=crypt()

w=s.split_n(crypt.words_of_number, 3)    	    
print(*w)
print(crypt.width)

