import ast
import random
f5=open('победа 0.txt', 'r')
a=f5.readlines()
lis=[]
dct={}

for i in range(0, len(a)):
	dct[i] = eval(a[i])

k=0
l=0
n=0
tttt=[]
for i in range(0, len(a)):
	if dct[i][n][k][l]=='x':
		# tttt[i]=dct[0][n]
		lis.append(i)
		d1="Это мне знакомо"
		# exit()
	else:
		d="я этого не знаю"
# print(e)
r=random.choice(lis)
print(lis)
for i in range(0, 3):
	for j in range(0, 3):
		if dct[r][n][i][j]=='0':
			s1=i
			s2=j
			tttt.append(i)
			tttt.append(j)
cvb=[]



print(cvb)


print(r)
print(tttt)


f5.close()



