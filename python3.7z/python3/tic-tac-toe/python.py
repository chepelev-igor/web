import random
import ast
li=[]
d= {}
class comp1:
	value="x"
	# number_turn=([1, 1, 1], [1, 1, 1], [1, 1, 1])
	number_turn=(['-', '-', '-'], ['-', '-', '-'], ['-', '-', '-'])
	number=2
	t=0
	t1=0
	t2=0
	t3=0
	t4=0
class comp2:
	value="0"
	number_turn=([0, 1, 2], [0, 1, 2], [0, 1, 2])
	number=2
plaer1 = [0, 1, 2]
plaer1_1 = [0, 1, 2]

f1=open('победа х.txt', 'a+')
f2=open('победа 0.txt', 'a+')
f3=open('ничья.txt', 'a+')

for h in range(0, 5):

	secure_random = random.SystemRandom()


	x=secure_random.choice(plaer1)
	y=secure_random.choice(plaer1_1)
	x2=secure_random.choice(plaer1)
	y2=secure_random.choice(plaer1_1)
	while comp1.number_turn[x2][y2] == comp2.value or comp1.number_turn[x][y] == comp1.value or comp1.number_turn[x2][y2] == comp1.value or comp1.number_turn[x][y] == comp2.value:
		x=secure_random.choice(plaer1)
		y=secure_random.choice(plaer1_1)
		x2=secure_random.choice(plaer1)
		y2=secure_random.choice(plaer1_1)
	comp1.number_turn[x][y]=comp1.value
	comp1.number_turn[x2][y2]=comp2.value
	string1=str(comp1.number_turn)
	testarray = ast.literal_eval(string1)
	d[h]=testarray

	# print(d[i])
	# d[h]=comp1.number_turn

	myString = str(d)

	# print(d[h])

	# myString1 = str(comp1.number_turn)
	
	# li.append(myString1)
	


	
	# print(comp1.number_turn)
	
# print(d[0])
# 
	

	if h>=2:
		for i in range(0, 3):
			
			if comp1.number_turn[0][0]==comp1.value and comp1.number_turn[1][1]==comp1.value and comp1.number_turn[2][2]==comp1.value:
				print('победа 1')
				f1.write(myString+'\n')
				f1.close()
				exit()

					
			if comp2.number_turn[0][0]==comp2.value and comp1.number_turn[1][1]==comp2.value and comp1.number_turn[2][2]==comp2.value:
				print('победа 2')
				f2.write(myString+'\n')
				f2.close()
				exit()

			if comp1.number_turn[0][2]==comp1.value and comp1.number_turn[1][1]==comp1.value and comp1.number_turn[2][0]==comp1.value:
				print('победа 1')
				f1.write(myString+'\n')
				f1.close()
				exit()

					
			if comp2.number_turn[0][2]==comp2.value and comp1.number_turn[1][1]==comp2.value and comp1.number_turn[2][0]==comp2.value:
				print('победа 2')
				f2.write(myString+'\n')
				f2.close()
				exit()

			for j in range(0, 3):
				
				if comp1.number_turn[i][j]==comp1.value:
					comp1.t1=comp1.t1+1;
						

				if comp1.number_turn[j][i]==comp1.value:
					comp1.t2=comp1.t2+1;
					
				if comp1.number_turn[i][j]==comp2.value:
					comp1.t3=comp1.t3+1;
					
				if comp1.number_turn[j][i]==comp2.value:
					comp1.t4=comp1.t4+1;
			if comp1.t1==3:
				print('победа 1')
				f1.write(myString+'\n')
				f1.close()
				exit()
			if comp1.t2==3:
				print('победа 1')
				f1.write(myString+'\n')
				f1.close()
				exit()
			if comp1.t3==3:
				print('победа 2')
				f2.write(myString+'\n')
				f2.close()
				exit()
			if comp1.t4==3:
				print('победа 2')
				f2.write(myString+'\n')				
				f2.close()
				exit()
			comp1.t1=0
			comp1.t2=0
			comp1.t3=0
			comp1.t4=0

				
if comp1.t4 != 3  and comp1.t3 != 3 and comp1.t2 != 3 and comp1.t1 != 3:
	print('ничья')
	f3.write(myString+'\n')
	f3.close()
	exit()


































































































































































































































































































































































































































