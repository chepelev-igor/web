<?php include_once ("handle/header.php");?>
<?php include_once ("handle/include_db.php");?>
<html>
 <head>
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Чат</title>

<link rel="stylesheet" type="text/css" href="style/latters/right_block.css" /> 
 </head>

<body>
<div class=mane_generely>

<div class="indecater_chat">
<?php include_once ("handle/writed.php");?>
<div class="indecater_chat_massage_person">
<?php include_once ("handle/read.php");?>
</div>

</div>

<div class="indecater_message">

<div class="indecater_message_login">
<form method="post" >

<textarea class="textarea_login" name="new_name" placeholder="введите свое имя" ></textarea>
<br><input class="text_botton" type="submit" name="enter_register_name" value="Регистрация"> <input class="text_botton" type="reset" value="Очистить">

</form>
</div>

<div class="indecater_message_massage">

<form method="post" >

<textarea class="textarea_message" name="new_message" placeholder="текст сообщения" required></textarea>
<br><input class="text_botton" type="submit" name="enter" value="Отправить"> <input class="text_botton" type="reset" value="Очистить">

</form>
</div>
</div>