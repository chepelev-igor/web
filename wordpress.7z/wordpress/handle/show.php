<?php
if($_POST['enter_register_name'])
{
 
  $_SESSION['name'] = $_POST['new_name'];  
  echo '<script>window.location.href = "index.php";</script>';
  
}

if($_POST['enter'])
{


  // $new_name=$_POST['new_name'];
  $new_message=$_POST['new_message'];
  
  $new_name=$_SESSION['name'];

  $add = $link->query("INSERT INTO new.chat(name, message) VALUES('$new_name', '$new_message')");

  
  echo '<script>window.location.href = "index.php";</script>';
  // echo "$users";
// echo $link;
 
  
}


$result = $link->query("select count(distinct name) from chat");