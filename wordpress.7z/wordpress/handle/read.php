<?php
while ($row1 = $result->fetch_assoc()) {
    echo "Число пользователей в чате: ".$row1['count(distinct name)']."<br>";
}


$users = $link->query("SELECT * FROM chat");

$num = 0;

 
    while(($row = $users->fetch_assoc()) != FALSE){
        $num++;
        $id = $row['id'];
        //выводим список на экран
        echo "<div class=indecater_chat_massage_person><p>".$num.".  ".$row['name']." отправил сообщения: ".$row['message']." </p></div>";

        //кнопка удаления пользователя
        // echo '
        //       <form method="get">
        //         <input type="hidden" name="id" value="'.$id.'">
        //         <input type="submit" name="del" value="Удалить пользователя" >
        //       </form>
        // ';
    }


?>
 <?php
 //закрываем соединение с БД
 $link->close();

 ?>