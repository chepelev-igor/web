
<?php

session_start();
/* подключение базы данных*/
 require_once("includes/connection.php"); 
 include("includes/header.php"); 	 

/* запись данных в базу*/
	if(isset($_POST["login"])){

	  if(!empty($_POST['username']) && !empty($_POST['password'])) {
             $username=htmlspecialchars($_POST['username']);
	         $password=htmlspecialchars($_POST['password']);
	         $query =mysql_query("SELECT * FROM account WHERE username='".$username."' AND password='".$password."'");
	         $numrows=mysql_num_rows($query);
	   if($numrows!=0)
 {
         while($row=mysql_fetch_assoc($query))
 {
	         $dbusername=$row['username'];
             $dbpassword=$row['password'];
 }
        if($username == $dbusername && $password == $dbpassword)
 {
	         $_SESSION['session_username']=$username;	 
	         echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=name')</script>";
	}

	} 
	else {
	//  ошибка1";
	      echo  "ошибка1";
 }
	} else {
            $message = "ошибка2";
	}
	}
	?>
   <pre class="registrwindow">
      <pre align="right"><strong><h2>Для того, чтобы нанять репетитора, 
войдите в систему или зарегистрируйтесь<a href="http://test1.ru/?option=registr"> здесь.</a> </h2></strong></pre>
    <form  method="post">
       <pre class="met1"> Фамилия, Имя </pre>
        <input class="input1" id="username" name="username"size="20" type="text" value=""></label></p>
        <pre class="met2">Введите ваш пороль </pre>
        <input class="input2" id="password" name="password"size="32" type="password" value=""></label></p> 
		<input class="input4" id="password" name="password"size="32"   type="text" value="" required>
        <input class="butt" name="login" type= "submit" value="Войти"></p>
    </form>
   </pre>
<?php include("includes/footer.php"); ?>