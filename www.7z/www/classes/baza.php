<?php
session_start();
header("Content-Type: text/html; charset=utf-8");
abstract class baza {

public function get_body(){
	
	
}
}
?>
<html>
  <head>
      <title></title>
  </head>
      <link rel="stylesheet" type="text/css" href="style.css" />
   <body>
      <div id="container">
      <div id="header">
        <div align="right">
         <h2>
          <script type="text/javascript">
            var d=new Date();
            document.write(d.toLocaleString());
        </script>
        </h2>
       </div>
     </div>

 
      <div id="navigation"></div>
      <div id="menu">


 
        <center>
          <form  method="post"></br>
              <p class="submit"><input class="button" id="register" name= "main" type="submit" value="Главная"></p></br>
            <!-- <p class="submit"><input class="button" id="register" name= "only" type="submit" value="Все о нас"></p></br>-->
              <p class="submit"><input class="button" id="register" name= "register" type="submit" value="Регистрация"></p></br>
              <p class="submit"><input class="button" id="register" name= "identification" type="submit" value="Нанять репетитора"></p></br>
              <p class="submit"><input class="button" id="register" name= "chat" type="submit" value="Задать вопрос"></p></br>
              <p class="submit"><input class="button" id="register" name= "contact" type="submit" value="Контакты"></p></br>
         </form>




        </center>
       </div>

 

       <div id="content"> 
       <center></br></br></br>
<?php
	$submit=$_POST['chat'];
      if(isset($submit))
{
           echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=chat')</script>";

}
       else
{
           echo "";    
}
$submit=$_POST['contact'];
      if(isset($submit))
{
           echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=contact')</script>";

}
       else
{
           echo "";    
}
	$submit=$_POST['main'];
      if(isset($submit))
{
           echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=main')</script>";

}
       else
{
           echo "";    
}
     $submit=$_POST['identification'];
        if(isset($submit))
{
             echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=identification')</script>";

}
        else
{
            echo "";    
}
	 $submi=$_POST['register'];
       if(isset($submi))
{
            echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=registr')</script>";
}
       else
{
            echo "";    
}
	



	

?>
      </center>
     </div>
        <div id="footer"> </div>
     </div>
  </body>


</html>
