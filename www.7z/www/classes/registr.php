<?php
session_start();

   class registr extends baza{
}
/* запись данных в базу*/
  require_once("includes/connection.php");
  include("includes/header.php");
	 if(isset($_POST["register"])){
	
	   if(!empty($_POST['username']) && !empty($_POST['password'])) {

              $username=htmlspecialchars($_POST['username']);
              $password=htmlspecialchars($_POST['password']);
              $password=htmlspecialchars($_POST['subject']);
              $query=mysql_query("SELECT * FROM account WHERE username='".$username."'");
              $numrows=mysql_num_rows($query);
         if($numrows==0)
   {
	            $sql="INSERT INTO account(username,password, cheg) VALUES('$username', '$password', '$subject' )";
                $result=mysql_query($sql);
          if($result){
	             $_SESSION['session_username']=$username;
	             $_SESSION['session_use']=$subject;
               echo '<script type="text/javascript">window.location = "http://test1.ru/?option=registr"</script>';

}   else {
              $messa = "Failed to insert data information!";
  
  }
	}
	  else {
	          $message = "That username already exists! Please try another one!";

  }
	}   else {
	            $message = "All fields are required!";
	}
	}
	?>

	<?php if (!empty($message)) {echo "<p class=\"error\">" . "MESSAGE: ". $message . "</p>";} ?>

    <pre class="registrwindow">
         <p align="right"><strong><h2>Будте внимательны с вводом данных:</strong></h2></p>
      <form  method="post"></br></br>
          <pre class="met1"> Ф. И. О </pre>
          <input class="input1" id="username" name="username"size="20" type="text" value="" required>
          <input class="input2" id="password" name="password"size="32"   type="text" value="" required>
          <input class="input3" id="password" name="password"size="32"   type="text" value="" required>
		  <pre class="met2"> Номер телефона </pre>
		  
		  <input class="input4"  type="text" placeholder="(___) ___ __ __" id="user_phone"> <pre class="met6"> или, почта: </pre>
		  <input class="input5" id="password" name="password"size="32"   type="text" value="" ><pre class="met3"> Ваш пороль </pre>
          <input class="input6" id="password" name="password"size="32"   type="password" value="" required>
    <pre class="registrwin">
 
     <pre class="registrwin">
          <input class="butt" id="register" name= "register" type="submit" value="Зарегистрироваться"></br></br></br> </br></br></br> 
    </form>
	</br></br></br>  
</pre>
<?php include("includes/footer.php"); ?>