<?php
session_start();
class name extends baza{
}
?>
<html>
  <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
         <title>Нанять репетитора</title>
 
   </head>

      <pre class="registrwindow">
        <form  method="post">

         <pre class="registrwin">
              <label for="user_pass">Выберите предмет<br>
                <select class="input" id="subject" name="subject"  size="1" >
                     <option select value = "Иван">Математика</option>
                     <option select value = "Иван">Иформатика</option>
                     <option select value = "Иван">Программирование</option>
                     <option select value = "Иван">Химия</option>
                     <option select value = "Иван">Физика</option>
		             <option select value = "Иван">Английский язык</option>
       
               </select>
	          <label for="user_pass">Кфаллификация репетиторов<br>
                 <select class="input" id="subject" name="subject"  size="1" >
                    <option select value = "Иван">не важно</option>
                    <option select value = "Иван">студент</option>
                    <option select value = "Иван">выпускник</option>
                    <option select value = "Иван">аспирант</option>
                    <option select value = "Иван">профессор</option>
  
                </select>
		      <label for="user_pass">Выберите пол репетитора<br>
                <select class="input" id="subject" name="subject"  size="1" >
                    <option select value = "Иван">мужской </option>
                    <option select value = "Иван">женский</option>
                    <option select value = "Иван">не важно</option>
        
                </select>
		      <label for="user_pass">Желаймый возвраст репетитора<br>
                <select class="input" id="subject" name="subject"  size="1" >
                    <option select value = "Иван">18-24</option>
                    <option select value = "Иван">24-32</option>
                    <option select value = "Иван">32-38</option>
		  
                    <option select value = "Иван">не важно</option>
        
  
                </select>
	      <input type="checkbox" name="option5" value="a5">Согласие с договором</p>
       <pre class="registrwin">
         <input class="butt" id="register" name= "register" type="submit" value="отправить заявку">
 </br></br></br> 
 </br></br></br> 
  </form>
	</br></br></br>  
      </pre>
</html>
<?php include("includes/footer.php"); ?>