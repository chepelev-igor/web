
<?php
session_start();
class chat extends baza{
}
/* запись данных в базу*/

if($_POST['enter'] and $_POST['text'])
{

echo "<script language='JavaScript' type='text/javascript'>window.scrollTo(0, 200) </script>";
	mysql_connect('localhost', 'root', '');
	mysql_select_db('id');
	date_default_timezone_set('UTC');
	$d=date('H:i:s A', strtotime('+3 hour'));
	$new_rates=$_POST['text'];
	$new=$_SESSION['session_username'];
	$ne=$_SESSION['session_use'];
	$a='Дождитесь ответа оператора...';
	mysql_query("INSERT  account SET message1='$new_rates', username='$new', message2='$d', message3='$a'");
	echo "<script language='JavaScript' type='text/javascript'>window.location.replace('http://test1.ru/?option=chat')</script>";
}
/* вывод данных на экран сайта*/
	mysql_connect('localhost', 'root', '');
	mysql_select_db('id');
$Query=mysql_query("SELECT * FROM account");
?>
 <pre class="chat"> 
<?php
while ($Row=mysql_fetch_assoc($Query)) {

	echo ' <p class="chat1">'.$Row['username'].' '.$Row['message2'].'</p>  &nbsp  '.$Row['message1'].'<p> '.$Row['message3'].'</p> </p>';

}?>
</pre>

<html>
 <head>
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Чат</title>
 
 </head>

<link rel="stylesheet" type="text/css" href="style.css" />
<body>

<form method="post" >

<textarea class="textarea" name="text" placeholder="текст сообщения" required></textarea>
<br><input class="text" type="submit" name="enter" value="Отправить"> <input class="tex" type="reset" value="Очистить">

</form>

 
</html>
